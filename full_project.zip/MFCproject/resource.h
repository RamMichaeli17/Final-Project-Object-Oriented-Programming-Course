//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MFCproject.rc
//
#define IDD_MFCPROJECT_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_RADIO1                      1000
#define IDC_RADIO2                      1001
#define IDC_BUTTON1                     1002
#define IDC_BUTTON2                     1003
#define IDC_EDIT2                       1006
#define IDC_BUTTON4                     1007
#define IDC_BUTTON5                     1008
#define IDC_BUTTON6                     1009
#define IDC_BUTTON7                     1010
#define IDC_BUTTON3                     1011
#define IDC_RADIO3                      1012
#define IDC_DATETIMEPICKER1             1014
#define IDC_RADIO5                      1019
#define IDC_RADIO6                      1020
#define IDC_BUTTON8                     1021
#define IDC_BUTTON9                     1025
#define IDC_EDIT1                       1026
#define IDC_BUTTON10                    1027
#define IDC_CHECK1                      1028
#define IDC_BUTTON11                    1029
#define IDC_BUTTON12                    1030
#define IDC_EDIT3                       1031
#define IDC_BUTTON13                    1032
#define IDC_BUTTON14                    1034
#define IDC_BUTTON15                    1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1035
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
